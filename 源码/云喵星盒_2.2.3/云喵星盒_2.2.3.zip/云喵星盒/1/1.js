webapp.清空浏览记录();
webapp.设置下拉刷新(true);
webapp.设置加载效果(true);
webapp.应用跳转提示(false);
webapp.设置自动安装(true);