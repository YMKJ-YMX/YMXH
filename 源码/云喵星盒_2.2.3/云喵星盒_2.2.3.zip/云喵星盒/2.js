(function() {
    const STORAGE_KEY = 'popupClosedTime';
    const TEXT_KEY = 'popupText';
    const NEVER_SHOW_KEY = 'popupNeverShow';
    const ONE_DAY = 24 * 60 * 60 * 1000;
    const POPUP_ID = 'customPopupWrapper';
    const POPUP_TEXT = '本软件所集成的大部分工具来源于第三方公开网络资源，若涉及侵权行为，请及时联系开发者进行处理与删除。';

    function isExpired() {
        if (localStorage.getItem(NEVER_SHOW_KEY) === 'true') return false;
        const storedTime = localStorage.getItem(STORAGE_KEY);
        const storedText = localStorage.getItem(TEXT_KEY);
        if (storedText !== POPUP_TEXT) return true;
        if (!storedTime) return true;
        const closedTime = parseInt(storedTime, 10);
        if (isNaN(closedTime)) return true;
        return (Date.now() - closedTime) >= ONE_DAY;
    }

    function removeExistingPopup() {
        const existing = document.getElementById(POPUP_ID);
        if (existing) existing.remove();
    }

    function showPopup() {
        removeExistingPopup();
        const originalOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';

        const overlay = document.createElement('div');
        overlay.id = POPUP_ID;
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.zIndex = '10000';

        const popup = document.createElement('div');
        popup.style.backgroundColor = '#ffffff';
        popup.style.borderRadius = '12px';
        popup.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.15)';
        popup.style.padding = '32px 28px 28px';
        popup.style.maxWidth = '400px';
        popup.style.width = '90%';
        popup.style.boxSizing = 'border-box';
        popup.style.fontFamily = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';

        const title = document.createElement('div');
        title.innerText = '免责声明';
        title.style.fontSize = '20px';
        title.style.fontWeight = '600';
        title.style.textAlign = 'center';
        title.style.marginBottom = '16px';
        title.style.color = '#1e1e1e';

        const content = document.createElement('div');
        content.style.whiteSpace = 'pre-line';
        content.style.textAlign = 'center';
        content.style.marginBottom = '28px';
        content.style.fontSize = '16px';
        content.style.lineHeight = '1.6';
        content.style.color = '#1e1e1e';
        content.innerText = POPUP_TEXT;

        const btnWrapper = document.createElement('div');
        btnWrapper.style.display = 'flex';
        btnWrapper.style.justifyContent = 'center';
        btnWrapper.style.gap = '16px';
        btnWrapper.style.flexWrap = 'wrap';

        const neverBtn = document.createElement('span');
        let neverCanClick = false;
        let neverTimer = null;
        let neverCountdown = 5;

        const baseStyle = {
            padding: '8px 24px',
            backgroundColor: '#ffffff',
            border: '1px solid #b0b0b0',
            borderRadius: '30px',
            fontSize: '15px',
            fontWeight: '500',
            transition: 'all 0.2s ease',
            userSelect: 'none',
            boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
        };

        Object.assign(neverBtn.style, baseStyle);
        neverBtn.innerText = `不再提醒 (${neverCountdown}s)`;
        neverBtn.style.cursor = 'not-allowed';
        neverBtn.style.opacity = '0.6';

        neverBtn.addEventListener('mouseenter', () => {
            if (!neverCanClick) return;
            neverBtn.style.backgroundColor = '#f5f5f5';
            neverBtn.style.borderColor = '#909090';
        });
        neverBtn.addEventListener('mouseleave', () => {
            if (!neverCanClick) return;
            neverBtn.style.backgroundColor = '#ffffff';
            neverBtn.style.borderColor = '#b0b0b0';
        });

        neverBtn.addEventListener('click', () => {
            if (!neverCanClick) return;
            if (neverTimer) {
                clearInterval(neverTimer);
                neverTimer = null;
            }
            localStorage.setItem(NEVER_SHOW_KEY, 'true');
            localStorage.removeItem(STORAGE_KEY);
            localStorage.removeItem(TEXT_KEY);
            overlay.remove();
            document.body.style.overflow = originalOverflow;
        });

        neverTimer = setInterval(() => {
            neverCountdown--;
            if (neverCountdown > 0) {
                neverBtn.innerText = `不再提醒 (${neverCountdown}s)`;
            } else {
                clearInterval(neverTimer);
                neverTimer = null;
                neverCanClick = true;
                neverBtn.innerText = '不再提醒';
                neverBtn.style.cursor = 'pointer';
                neverBtn.style.opacity = '1';
                neverBtn.style.backgroundColor = '#ffffff';
                neverBtn.style.borderColor = '#b0b0b0';
            }
        }, 1000);

        const closeBtn = document.createElement('span');
        Object.assign(closeBtn.style, baseStyle);
        closeBtn.innerText = '确认';
        closeBtn.style.cursor = 'pointer';
        closeBtn.style.opacity = '1';

        closeBtn.addEventListener('mouseenter', () => {
            closeBtn.style.backgroundColor = '#f5f5f5';
            closeBtn.style.borderColor = '#909090';
        });
        closeBtn.addEventListener('mouseleave', () => {
            closeBtn.style.backgroundColor = '#ffffff';
            closeBtn.style.borderColor = '#b0b0b0';
        });

        closeBtn.addEventListener('click', () => {
            if (neverTimer) {
                clearInterval(neverTimer);
                neverTimer = null;
            }
            localStorage.setItem(STORAGE_KEY, Date.now().toString());
            localStorage.setItem(TEXT_KEY, POPUP_TEXT);
            overlay.remove();
            document.body.style.overflow = originalOverflow;
        });

        btnWrapper.appendChild(neverBtn);
        btnWrapper.appendChild(closeBtn);
        popup.appendChild(title);
        popup.appendChild(content);
        popup.appendChild(btnWrapper);
        overlay.appendChild(popup);
        document.body.appendChild(overlay);
    }

    function init() {
        if (isExpired()) {
            showPopup();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();