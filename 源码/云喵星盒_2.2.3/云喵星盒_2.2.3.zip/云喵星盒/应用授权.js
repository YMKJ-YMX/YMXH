(function() {
    const STORAGE_KEY = 'userInfo';
    const AUTH_URL = '授权.txt';

    function getUserQQ() {
        try {
            const info = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
            return info.qq || null;
        } catch (e) {
            return null;
        }
    }

    function showToast(msg) {
        if (typeof webapp !== 'undefined' && webapp.显示文本提示) {
            webapp.显示文本提示(msg);
        } else {
            alert(msg);
        }
    }

    function copyToClipboard(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text);
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
        }
    }

    async function fetchAppList() {
        const resp = await fetch(AUTH_URL);
        const text = await resp.text();
        const lines = text.split(/\r?\n/);
        const apps = [];
        const regex = /应用名称：([^/]+)\/应用包名：([^/]+)\/应用图标：(.+?)\/权限描述：([^/]+)\/状态：(\d+)/;
        for (const line of lines) {
            if (!line.trim()) continue;
            const match = line.match(regex);
            if (match) {
                apps.push({
                    name: match[1].trim(),
                    packageName: match[2].trim(),
                    icon: match[3].trim(),
                    description: match[4].trim(),
                    status: match[5].trim()
                });
            }
        }
        return apps;
    }

    function extractPackageNames(clipText) {
        let packages = [];
        try {
            const parsed = JSON.parse(clipText);
            if (Array.isArray(parsed)) {
                packages = parsed.filter(v => typeof v === 'string');
            }
        } catch (e) {}
        if (packages.length === 0) {
            const regex = /[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+/g;
            const matches = clipText.match(regex);
            if (matches) packages = matches;
        }
        return packages;
    }

    async function getClipboard() {
        if (typeof webapp !== 'undefined' && webapp.获取粘贴内容) {
            return await webapp.获取粘贴内容();
        }
        return '';
    }

    function showAuthDialog(app) {
        const existing = document.getElementById('__auth_modal_root__');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = '__auth_modal_root__';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100000;
            opacity: 0;
            transition: opacity 0.2s;
        `;

        const modal = document.createElement('div');
        modal.style.cssText = `
            background: white;
            width: calc(100% - 48px);
            max-width: 340px;
            border-radius: 28px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            transform: scale(0.95);
            transition: transform 0.2s ease;
        `;

        const row = document.createElement('div');
        row.style.cssText = 'display: flex; gap: 16px; align-items: center; margin-bottom: 20px;';

        const iconWrap = document.createElement('div');
        iconWrap.style.cssText = 'flex-shrink: 0;';
        const iconImg = document.createElement('img');
        iconImg.src = app.icon;
        iconImg.style.cssText = 'width: 60px; height: 60px; border-radius: 16px; object-fit: cover;';
        iconImg.onerror = () => {
            iconImg.style.display = 'none';
            const placeholder = document.createElement('div');
            placeholder.style.cssText = 'width: 60px; height: 60px; border-radius: 16px; background: #e0e0e0;';
            iconWrap.innerHTML = '';
            iconWrap.appendChild(placeholder);
        };
        iconWrap.appendChild(iconImg);

        const rightCol = document.createElement('div');
        rightCol.style.cssText = 'flex: 1;';

        const nameEl = document.createElement('div');
        nameEl.textContent = app.name;
        nameEl.style.cssText = 'font-size: 1.1rem; font-weight: 600; color: #2c3e50; margin-bottom: 4px;';

        const descEl = document.createElement('div');
        descEl.textContent = app.description;
        descEl.style.cssText = 'font-size: 0.85rem; color: #666; line-height: 1.3;';

        rightCol.appendChild(nameEl);
        rightCol.appendChild(descEl);
        row.appendChild(iconWrap);
        row.appendChild(rightCol);

        const statusHint = document.createElement('div');
        if (app.status === '2') {
            statusHint.textContent = '此应用的授权功能已被“云喵安全中心”停用';
            statusHint.style.cssText = 'color: #f44336; font-size: 0.8rem; margin-bottom: 16px; text-align: center; line-height: 1.4;';
        } else {
            statusHint.style.display = 'none';
        }

        const btnGroup = document.createElement('div');
        btnGroup.style.cssText = 'display: flex; gap: 12px; margin-top: 8px;';

        if (app.status === '2') {
            const cancelBtn = document.createElement('button');
            cancelBtn.textContent = '取消';
            cancelBtn.style.cssText = `
                flex: 1;
                background: transparent;
                color: #7f8c8d;
                border: 1px solid #e0e0e0;
                padding: 12px 0;
                border-radius: 40px;
                font-size: 1rem;
                cursor: pointer;
            `;
            btnGroup.appendChild(cancelBtn);
            cancelBtn.onclick = () => {
                showToast('已取消授权');
                closeModal();
            };
        } else {
            const cancelBtn = document.createElement('button');
            cancelBtn.textContent = '取消';
            cancelBtn.style.cssText = `
                flex: 1;
                background: transparent;
                color: #7f8c8d;
                border: 1px solid #e0e0e0;
                padding: 12px 0;
                border-radius: 40px;
                font-size: 1rem;
                cursor: pointer;
            `;
            const authBtn = document.createElement('button');
            authBtn.textContent = '授权';
            authBtn.style.cssText = `
                flex: 1;
                background: #6a89cc;
                color: white;
                border: none;
                padding: 12px 0;
                border-radius: 40px;
                font-size: 1rem;
                font-weight: 500;
                cursor: pointer;
            `;
            btnGroup.appendChild(cancelBtn);
            btnGroup.appendChild(authBtn);
            cancelBtn.onclick = () => {
                showToast('已取消授权');
                closeModal();
            };
            authBtn.onclick = () => {
                if (app.status === '1') {
                    const qq = getUserQQ();
                    if (!qq) {
                        showToast('错误信息，您没有登录');
                        closeModal();
                        return;
                    }
                    copyToClipboard(JSON.stringify([qq]));
                    showToast('已授权');
                    if (typeof webapp !== 'undefined' && webapp.启动指定应用) {
                        webapp.启动指定应用(app.packageName);
                    }
                    closeModal();
                } else {
                    showToast('未知状态');
                    closeModal();
                }
            };
        }

        modal.appendChild(row);
        modal.appendChild(statusHint);
        modal.appendChild(btnGroup);
        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            modal.style.transform = 'scale(1)';
        });

        const closeModal = () => {
            overlay.style.opacity = '0';
            modal.style.transform = 'scale(0.95)';
            setTimeout(() => overlay.remove(), 200);
        };

        overlay.onclick = (e) => { if (e.target === overlay) closeModal(); };
    }

    (async function() {
        try {
            const clipText = await getClipboard();
            if (!clipText) return;

            const appList = await fetchAppList();
            const packages = extractPackageNames(clipText);
            if (packages.length === 0) return;

            let matched = null;
            for (const pkg of packages) {
                matched = appList.find(app => app.packageName === pkg);
                if (matched) break;
            }
            if (!matched) return;

            const qq = getUserQQ();
            if (!qq) {
                showToast('错误信息，您没有登录');
                return;
            }

            showAuthDialog(matched);
        } catch (err) {
            console.error(err);
        }
    })();
})();