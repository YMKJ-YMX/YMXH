(function(){
    const STORAGE_KEY='ymx_announcement_last_content';
    const HIDE_KEY='ymx_announcement_hide';
    let activeInterval=null;
    let styleInjected=false;
    function injectStyles(){
        if(styleInjected)return;
        const style=document.createElement('style');
        style.textContent=`
            .ymx-announce-overlay{
                position:fixed;
                top:0;
                left:0;
                width:100%;
                height:100%;
                background-color:rgba(0,0,0,0.6);
                backdrop-filter:blur(8px);
                display:flex;
                align-items:center;
                justify-content:center;
                z-index:2147483647;
                opacity:0;
                visibility:hidden;
                transition:opacity 0.3s ease,visibility 0.3s ease;
            }
            .ymx-announce-overlay.active{
                opacity:1;
                visibility:visible;
            }
            .ymx-announce-content{
                background-color:#fff;
                width:90%;
                max-width:540px;
                max-height:85vh;
                display:flex;
                flex-direction:column;
                border-radius:16px;
                border:1.5px solid #666;
                box-shadow:0 10px 30px rgba(0,0,0,0.3);
                transform:scale(0.9);
                opacity:0;
                transition:transform 0.25s cubic-bezier(0.2,0.9,0.4,1.1),opacity 0.2s ease;
                overflow:hidden;
            }
            .ymx-announce-overlay.active .ymx-announce-content{
                transform:scale(1);
                opacity:1;
            }
            .ymx-announce-header{
                padding:16px 20px 8px 20px;
                border-bottom:1px solid #666;
                background:#fff;
            }
            .ymx-announce-title{
                font-size:1.2rem;
                font-weight:600;
                color:#000;
                margin:0;
            }
            .ymx-announce-body{
                padding:16px 20px;
                line-height:1.5;
                font-size:0.9rem;
                white-space:pre-wrap;
                word-wrap:break-word;
                color:#000;
                background:#fff;
                overflow-y:auto;
                flex:1;
            }
            .ymx-announce-actions{
                padding:16px 20px;
                border-top:1px solid #eee;
                display:flex;
                justify-content:flex-end;
                background:#fff;
            }
            .ymx-announce-btn{
                background-color:#000;
                color:#fff;
                border:1px solid #000;
                padding:8px 20px;
                border-radius:8px;
                font-size:0.9rem;
                font-weight:500;
                cursor:pointer;
                transition:transform 0.2s,background 0.2s;
                font-family:inherit;
            }
            .ymx-announce-btn:active{
                transform:scale(0.96);
            }
            .ymx-announce-btn:disabled{
                background-color:#ccc;
                border-color:#ccc;
                color:#666;
                cursor:not-allowed;
                transform:none;
            }
            @media (max-width:560px){
                .ymx-announce-content{
                    width:92%;
                }
                .ymx-announce-header{
                    padding:14px 16px 6px 16px;
                }
                .ymx-announce-body{
                    padding:14px 16px;
                }
                .ymx-announce-actions{
                    padding:12px 16px;
                }
            }
        `;
        document.head.appendChild(style);
        styleInjected=true;
    }
    function disableBodyScroll(){
        document.body.style.overflow='hidden';
    }
    function enableBodyScroll(){
        document.body.style.overflow='';
    }
    function clearActiveInterval(){
        if(activeInterval){
            clearInterval(activeInterval);
            activeInterval=null;
        }
    }
    function removeExistingModal(){
        const existing=document.getElementById('ymxAnnouncementModal');
        if(existing){
            if(existing._intervalId)clearInterval(existing._intervalId);
            existing.remove();
        }
        clearActiveInterval();
    }
    async function fetchAnnouncement(){
        try{
            const url='公告.txt?_t='+Date.now();
            const response=await fetch(url,{
                method:'GET',
                mode:'cors',
                headers:{
                    'Accept':'text/plain',
                    'Cache-Control':'no-cache'
                }
            });
            if(!response.ok)return;
            const content=await response.text();
            checkAndShowAnnouncement(content.trim());
        }catch(error){}
    }
    function checkAndShowAnnouncement(content){
        if(!content)return;
        const lastContent=localStorage.getItem(STORAGE_KEY);
        const isHidden=localStorage.getItem(HIDE_KEY)==='true';
        if(isHidden&&lastContent===content)return;
        showSystemAlert(content);
    }
    function showSystemAlert(content){
        removeExistingModal();
        disableBodyScroll();
        const overlay=document.createElement('div');
        overlay.className='ymx-announce-overlay';
        overlay.id='ymxAnnouncementModal';
        const modalContent=document.createElement('div');
        modalContent.className='ymx-announce-content';
        const header=document.createElement('div');
        header.className='ymx-announce-header';
        const title=document.createElement('h3');
        title.className='ymx-announce-title';
        title.textContent='公告';
        header.appendChild(title);
        const body=document.createElement('div');
        body.className='ymx-announce-body';
        const contentDiv=document.createElement('div');
        contentDiv.style.whiteSpace='pre-wrap';
        contentDiv.textContent=content;
        body.appendChild(contentDiv);
        const actions=document.createElement('div');
        actions.className='ymx-announce-actions';
        const confirmBtn=document.createElement('button');
        confirmBtn.className='ymx-announce-btn';
        confirmBtn.disabled=true;
        actions.appendChild(confirmBtn);
        modalContent.appendChild(header);
        modalContent.appendChild(body);
        modalContent.appendChild(actions);
        overlay.appendChild(modalContent);
        document.body.appendChild(overlay);
        requestAnimationFrame(()=>{
            overlay.classList.add('active');
        });
        let secondsLeft=5;
        const updateButtonState=()=>{
            if(secondsLeft>0){
                confirmBtn.textContent=`请仔细阅读 (${secondsLeft}s)`;
                confirmBtn.disabled=true;
            }else{
                confirmBtn.textContent='知道了';
                confirmBtn.disabled=false;
            }
        };
        updateButtonState();
        const intervalId=setInterval(()=>{
            secondsLeft--;
            updateButtonState();
            if(secondsLeft<=0){
                clearInterval(intervalId);
                if(overlay._intervalId)overlay._intervalId=null;
                if(activeInterval===intervalId)activeInterval=null;
            }
        },1000);
        overlay._intervalId=intervalId;
        activeInterval=intervalId;
        const confirmHandler=()=>{
            if(confirmBtn.disabled)return;
            if(overlay._intervalId)clearInterval(overlay._intervalId);
            if(activeInterval===intervalId)activeInterval=null;
            localStorage.setItem(HIDE_KEY,'true');
            localStorage.setItem(STORAGE_KEY,content);
            enableBodyScroll();
            overlay.remove();
        };
        confirmBtn.addEventListener('click',confirmHandler);
    }
    window.showAnnouncement=function(){
        localStorage.removeItem(HIDE_KEY);
        fetchAnnouncement();
    };
    window.clearAnnouncementPrefs=function(){
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem(HIDE_KEY);
    };
    injectStyles();
    if(document.readyState==='loading'){
        document.addEventListener('DOMContentLoaded',fetchAnnouncement);
    }else{
        fetchAnnouncement();
    }
})();