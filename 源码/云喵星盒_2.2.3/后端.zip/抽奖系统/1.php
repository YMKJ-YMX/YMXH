<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
$saveDir = __DIR__ . "/data";
$blackFile = $saveDir . "/blacklist.txt";
if (!file_exists($saveDir)) mkdir($saveDir, 0755, true);
if (!file_exists($blackFile)) file_put_contents($blackFile,"");
function getIp(){
    if(isset($_SERVER['REMOTE_ADDR'])){
        $ip = $_SERVER['REMOTE_ADDR'];
        if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)){
            return $ip;
        }
    }
    $check = ['HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','HTTP_X_REAL_IP'];
    foreach($check as $k){
        if(!empty($_SERVER[$k])){
            $ips = explode(',',$_SERVER[$k]);
            foreach($ips as $tmpIp){
                $tmpIp = trim($tmpIp);
                if(filter_var($tmpIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)){
                    return $tmpIp;
                }
            }
        }
    }
    return "0.0.0.0";
}
$ip = getIp();
$qq = isset($_GET["qq"]) ? trim($_GET["qq"]) : "";
$content = isset($_GET["content"]) ? trim($_GET["content"]) : "";
if ($qq === "" || $content === "") {
    echo json_encode(["code"=>400,"msg"=>"参数缺失"],JSON_UNESCAPED_UNICODE);
    exit;
}
if (!ctype_digit($qq)) {
    echo json_encode(["code"=>500,"msg"=>"提交失败"],JSON_UNESCAPED_UNICODE);
    exit;
}
$blackRaw = @file_get_contents($blackFile);
$blackArr = explode("\n",$blackRaw);
$isBlack = false;
foreach($blackArr as $b){
    if(trim($b)===$qq){
        $isBlack = true;
        break;
    }
}
if($isBlack){
    echo json_encode(["code"=>403,"msg"=>"QQ已被封禁"],JSON_UNESCAPED_UNICODE);
    exit;
}
$today = date("Ymd");
$allFiles = array_merge(glob($saveDir."/*.txt"),glob($saveDir."/done/*.txt"));
foreach($allFiles as $filePath){
    $fileName = basename($filePath);
    if($fileName == "oper_log.txt" || $fileName == "blacklist.txt") continue;
    $fileDate = substr($fileName,0,8);
    if($fileDate != $today) continue;
    $raw = @file_get_contents($filePath);
    $lines = explode("\n",$raw);
    $fileQq = trim($lines[0] ?? "");
    $fileIp = trim($lines[2] ?? "");
    if($fileQq === $qq || $fileIp === $ip){
        echo json_encode(["code"=>403,"msg"=>"请勿重复提交"],JSON_UNESCAPED_UNICODE);
        exit;
    }
}
$fileName = date("Ymd_His") . "_" . mt_rand(1000,9999) . ".txt";
$saveText = $qq."\n".$content."\n".$ip;
$fullPath = $saveDir."/".$fileName;
if(file_put_contents($fullPath,$saveText)){
    echo json_encode(["code"=>200,"msg"=>"提交成功"],JSON_UNESCAPED_UNICODE);
}else{
    echo json_encode(["code"=>500,"msg"=>"提交失败"],JSON_UNESCAPED_UNICODE);
}
exit;
?>
