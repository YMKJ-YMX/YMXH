<?php
error_reporting(0);
ini_set("display_errors",0);
$dir = __DIR__ . "/data";
$doneDir = $dir . "/done";
$blackFile = $dir . "/blacklist.txt";
$operLogFile = $dir . "/oper_log.txt";
$remarkFile = $dir . "/remarks.json";
if (!file_exists($dir)) mkdir($dir,0755,true);
if (!file_exists($doneDir)) mkdir($doneDir,0755,true);
if (!file_exists($blackFile)) file_put_contents($blackFile,"");
if (!file_exists($operLogFile)) file_put_contents($operLogFile,"");
if (!file_exists($remarkFile)) file_put_contents($remarkFile,json_encode([]));
function writeOperLog($text){
    global $operLogFile;
    $time = date("Y-m-d H:i:s");
    file_put_contents($operLogFile,"[{$time}] {$text}\n",FILE_APPEND);
}
function getRemarks(){
    global $remarkFile;
    $content = file_get_contents($remarkFile);
    $data = json_decode($content,true);
    if(!is_array($data)) $data = [];
    return $data;
}
function saveRemarks($data){
    global $remarkFile;
    file_put_contents($remarkFile,json_encode($data,JSON_UNESCAPED_UNICODE));
}
if (isset($_GET['addBlack'])) {
    $qq = trim($_GET['addBlack']);
    if(ctype_digit($qq)){
        $blackTxt = file_get_contents($blackFile);
        $lines = explode("\n",$blackTxt);
        $exist = false;
        foreach($lines as $l){
            if(trim($l)==$qq){$exist=true;break;}
        }
        if(!$exist){
            file_put_contents($blackFile,$blackTxt.$qq."\n");
            writeOperLog("添加黑名单QQ：{$qq}");
        }
    }
    exit(json_encode(['code'=>200]));
}
if (isset($_GET['delBlack'])) {
    $qq = trim($_GET['delBlack']);
    $lines = file($blackFile);
    $newLines = [];
    foreach($lines as $l){
        if(trim($l)!=$qq) $newLines[] = $l;
    }
    file_put_contents($blackFile,implode("",$newLines));
    writeOperLog("移除黑名单QQ：{$qq}");
    exit(json_encode(['code'=>200]));
}
if (isset($_GET['del'])) {
    $delFile = basename($_GET['del']);
    $targetDir = isset($_GET['dir']) && $_GET['dir'] == 'done' ? $doneDir : $dir;
    $delPath = $targetDir . "/" . $delFile;
    if (file_exists($delPath)) {
        $content = @file_get_contents($delPath);
        $lines = explode("\n",$content);
        $qq = trim($lines[0]??"未知QQ");
        unlink($delPath);
        writeOperLog("删除文件【{$delFile}】提交QQ：{$qq}");
    }
    exit(json_encode(['code'=>200]));
}
if (isset($_GET['done'])) {
    $oldFile = basename($_GET['done']);
    $oldPath = $dir . "/" . $oldFile;
    if(file_exists($oldPath)){
        $content = @file_get_contents($oldPath);
        $lines = explode("\n",$content);
        $qq = trim($lines[0]??"未知QQ");
        rename($oldPath,$doneDir."/".$oldFile);
        touch($doneDir."/".$oldFile);
        writeOperLog("标记完成文件【{$oldFile}】提交QQ：{$qq}");
    }
    exit(json_encode(['code'=>200]));
}
if (isset($_GET['setRemark'])) {
    $qq = trim($_GET['qq']);
    $remark = trim($_GET['remark'] ?? '');
    if(ctype_digit($qq)){
        $remarks = getRemarks();
        if($remark === ''){
            unset($remarks[$qq]);
        }else{
            $remarks[$qq] = $remark;
        }
        saveRemarks($remarks);
        writeOperLog("设置备注 QQ:{$qq} -> {$remark}");
    }
    exit(json_encode(['code'=>200]));
}
if(isset($_GET['getData'])){
    $waitList = [];
    $doneList = [];
    $blackList = [];
    $operLogRaw = file_get_contents($operLogFile);
    $operLogArr = array_filter(explode("\n",$operLogRaw));
    rsort($operLogArr);
    $blackRaw = file_get_contents($blackFile);
    $blackArr = array_filter(explode("\n",$blackRaw));
    foreach($blackArr as $bqq){
        $t = trim($bqq);
        if($t!="") $blackList[] = $t;
    }
    $remarks = getRemarks();
    $files = glob($dir . "/*.txt");
    foreach ($files as $file) {
        $fname = basename($file);
        if($fname === 'oper_log.txt' || $fname === 'blacklist.txt') continue;
        if(!file_exists($file)) continue;
        $text = @file_get_contents($file);
        $mtime = @filemtime($file);
        $time = $mtime ? date("m-d H:i", $mtime) : "未知时间";
        $lines = explode("\n", $text);
        $qq = trim($lines[0] ?? "");
        $content = trim($lines[1] ?? "");
        $ip = trim($lines[2] ?? "");
        if($qq !== "" || $content !== ""){
            $waitList[] = ["file"=>$fname,"qq"=>$qq,"content"=>$content,"time"=>$time,"ip"=>$ip,"mtime"=>$mtime];
        }
    }
    usort($waitList,function($a,$b){
        return $b['mtime'] - $a['mtime'];
    });
    $doneFiles = glob($doneDir . "/*.txt");
    foreach ($doneFiles as $file) {
        if(!file_exists($file)) continue;
        $text = @file_get_contents($file);
        $mtime = @filemtime($file);
        $time = $mtime ? date("m-d H:i", $mtime) : "未知时间";
        $lines = explode("\n", $text);
        $qq = trim($lines[0] ?? "");
        $content = trim($lines[1] ?? "");
        $ip = trim($lines[2] ?? "");
        if($qq !== "" || $content !== ""){
            $doneList[] = ["file"=>basename($file),"qq"=>$qq,"content"=>$content,"time"=>$time,"ip"=>$ip,"mtime"=>$mtime];
        }
    }
    usort($doneList,function($a,$b){
        return $b['mtime'] - $a['mtime'];
    });
    exit(json_encode([
        'wait'=>$waitList,
        'done'=>$doneList,
        'black'=>$blackList,
        'operLog'=>$operLogArr,
        'remarks'=>$remarks
    ],JSON_UNESCAPED_UNICODE));
}
$waitList = [];
$doneList = [];
$blackList = [];
$operLogRaw = file_get_contents($operLogFile);
$operLogArr = array_filter(explode("\n",$operLogRaw));
rsort($operLogArr);
$blackRaw = file_get_contents($blackFile);
$blackArr = array_filter(explode("\n",$blackRaw));
foreach($blackArr as $bqq){
    $t = trim($bqq);
    if($t!="") $blackList[] = $t;
}
$remarks = getRemarks();
$files = glob($dir . "/*.txt");
foreach ($files as $file) {
    $fname = basename($file);
    if($fname === 'oper_log.txt' || $fname === 'blacklist.txt') continue;
    if(!file_exists($file)) continue;
    $text = @file_get_contents($file);
    $mtime = @filemtime($file);
    $time = $mtime ? date("m-d H:i", $mtime) : "未知时间";
    $lines = explode("\n", $text);
    $qq = trim($lines[0] ?? "");
    $content = trim($lines[1] ?? "");
    $ip = trim($lines[2] ?? "");
    if($qq !== "" || $content !== ""){
        $waitList[] = ["file"=>$fname,"qq"=>$qq,"content"=>$content,"time"=>$time,"ip"=>$ip,"mtime"=>$mtime];
    }
}
usort($waitList,function($a,$b){
    return $b['mtime'] - $a['mtime'];
});
$doneFiles = glob($doneDir . "/*.txt");
foreach ($doneFiles as $file) {
    if(!file_exists($file)) continue;
    $text = @file_get_contents($file);
    $mtime = @filemtime($file);
    $time = $mtime ? date("m-d H:i", $mtime) : "未知时间";
    $lines = explode("\n", $text);
    $qq = trim($lines[0] ?? "");
    $content = trim($lines[1] ?? "");
    $ip = trim($lines[2] ?? "");
    if($qq !== "" || $content !== ""){
        $doneList[] = ["file"=>basename($file),"qq"=>$qq,"content"=>$content,"time"=>$time,"ip"=>$ip,"mtime"=>$mtime];
    }
}
usort($doneList,function($a,$b){
    return $b['mtime'] - $a['mtime'];
});
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, shrink-to-fit=no">
<style>
html,body{height:100%;overflow:hidden}
body{background:#f2f2f2;padding:6px 6px 30px 6px;font-size:13px;display:flex;flex-direction:column;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
.title{text-align:center;padding:8px 0;font-size:16px;font-weight:bold;flex-shrink:0}
.tabBox{display:flex;background:#fff;border-radius:6px;margin-bottom:8px;position:relative;flex-shrink:0}
.tab{flex:1;text-align:center;padding:10px 4px;font-size:13px;position:relative;z-index:2;color:#333}
.tab.active{color:#fff}
.tabActiveBg{position:absolute;width:25%;height:100%;background:#000;left:0;top:0;border-radius:6px;transition:left 0.3s ease}
.contentWrap{flex:1;overflow:hidden;display:flex;flex-direction:column}
.contentBox{width:400%;display:flex;transition:transform 0.3s ease;height:100%}
.contentPage{width:25%;height:100%;overflow-y:auto;padding-bottom:10px}
.card{background:#fff;border-radius:6px;padding:6px;margin-bottom:6px;display:flex;gap:6px;align-items:center}
.avatar{width:36px;height:36px;border-radius:50%;object-fit:cover;background:#eee}
.info{flex:1}
.qq{font-weight:bold;color:#6a89cc;font-size:14px;cursor:pointer;display:inline-block;touch-action:manipulation}
.time{font-size:10px;color:#888}
.ip{font-size:10px;color:#666;margin-top:2px}
.content{margin-top:2px;color:#333;word-break:break-all}
.btnGroup{display:flex;gap:4px;flex-wrap:wrap}
.doneBtn{background:#00b42a;color:#fff;border:0;border-radius:3px;padding:3px 6px}
.delBtn{background:#f44336;color:#fff;border:0;border-radius:3px;padding:3px 6px}
.blackBtn{background:#333;color:#fff;border:0;border-radius:3px;padding:3px 6px}
.blackDel{background:#999;color:#fff;border:0;border-radius:3px;padding:2px 5px}
.empty{text-align:center;padding:30px 0;color:#777}
img{border:none;display:block}
button,a{outline:none;-webkit-tap-highlight-color:transparent}
.addBlackBox{display:flex;gap:6px;margin-bottom:10px}
#blackInput{flex:1;padding:5px;border:1px #ccc solid;outline:none;background:#fff;border-radius:4px}
.addBlackBtn{background:#000;color:#fff;border:0;border-radius:4px;padding:0 8px}
.logItem{background:#fff;padding:6px;margin-bottom:3px;word-break:break-all;line-height:1.4;font-size:12px}
.toast{position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.85);color:#fff;padding:8px 16px;border-radius:6px;font-size:13px;z:9999;opacity:0;transition:opacity 0.25s;pointer-events:none}
.toast.show{opacity:1}
.footer{text-align:center;padding:10px 0 10px 0;flex-shrink:0;font-size:12px;color:#999;margin-top:2px}
.footer a{color:#999;text-decoration:none}
</style>
<title>抽奖数据</title>
</head>
<body>
<div class="title">抽奖数据</div>
<div class="tabBox">
<div class="tabActiveBg" id="tabSlider"></div>
<div class="tab active" onclick="switchTab(0)">待处理</div>
<div class="tab" onclick="switchTab(1)">已处理</div>
<div class="tab" onclick="switchTab(2)">黑名单</div>
<div class="tab" onclick="switchTab(3)">操作日志</div>
</div>
<div class="contentWrap">
<div class="contentBox" id="contentContainer">
<div class="contentPage" id="waitBox"></div>
<div class="contentPage" id="doneBox"></div>
<div class="contentPage" id="blackBox">
<div class="addBlackBox">
<input type="text" id="blackInput" placeholder="输入QQ添加黑名单">
<button class="addBlackBtn" onclick="addBlack()">添加</button>
</div>
<div id="blackListWrap"></div>
</div>
<div class="contentPage" id="logBox"></div>
</div>
</div>
<div class="footer">
<a href="https://icp.gov.moe/?keyword=20261070" target="_blank">萌ICP备20261070号</a>
</div>
<div class="toast" id="toast"></div>
<script>
let currentTab = 0;
const toastEl = document.getElementById('toast');
function showToast(msg){
    toastEl.innerText = msg;
    toastEl.classList.add('show');
    setTimeout(()=>toastEl.classList.remove('show'),1800);
}
function htmlEscape(str){
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}
let remarksData = {};
function renderCardList(list,isWait,remarks){
    if(list.length === 0){
        return '<div class="empty">暂无抽奖数据</div>';
    }
    let html = '';
    list.forEach(item=>{
        let avatarHtml = '';
        if(item.qq){
            avatarHtml = `<img class="avatar" src="http://q.qlogo.cn/headimg_dl?dst_uin=${encodeURIComponent(item.qq)}&spec=640&img_type=jpg" alt="头像" onerror="this.style.background='#eee';this.src=''">`;
        }else{
            avatarHtml = '<div class="avatar"></div>';
        }
        let displayQQ = item.qq;
        if(remarks && item.qq && remarks[item.qq]){
            displayQQ = remarks[item.qq];
        }
        let btnHtml = '';
        if(isWait){
            btnHtml = `
                <div class="btnGroup">
                    <button class="doneBtn" onclick="handleDone('${encodeURIComponent(item.file)}')">完成</button>
                    <button class="blackBtn" onclick="quickAddBlack('${encodeURIComponent(item.qq)}')">拉黑</button>
                    <button class="delBtn" onclick="handleDel('${encodeURIComponent(item.file)}',false)">删除</button>
                </div>
            `;
        }else{
            btnHtml = `
                <div class="btnGroup">
                    <button class="blackBtn" onclick="quickAddBlack('${encodeURIComponent(item.qq)}')">拉黑</button>
                    <button class="delBtn" onclick="handleDel('${encodeURIComponent(item.file)}',true)">删除</button>
                </div>
            `;
        }
        let qqAttr = item.qq ? `data-qq="${htmlEscape(item.qq)}"` : '';
        let displayText = htmlEscape(displayQQ);
        html += `
            <div class="card">
                ${avatarHtml}
                <div class="info">
                    <div class="qq" ${qqAttr} onclick="copyQQ(this)" oncontextmenu="event.preventDefault();longPressQQ(this)">${displayText}</div>
                    <div class="time">${htmlEscape(item.time)}</div>
                    <div class="ip">IP：${htmlEscape(item.ip)}</div>
                    <div class="content">${htmlEscape(item.content)}</div>
                </div>
                ${btnHtml}
            </div>
        `;
    });
    return html;
}
function renderBlack(blackArr,remarks){
    if(blackArr.length===0) return '<div class="empty">暂无黑名单QQ</div>';
    let h = '';
    blackArr.forEach(qq=>{
        let displayQQ = qq;
        if(remarks && remarks[qq]){
            displayQQ = remarks[qq];
        }
        let avatarHtml = `<img class="avatar" src="http://q.qlogo.cn/headimg_dl?dst_uin=${encodeURIComponent(qq)}&spec=640&img_type=jpg" alt="头像" onerror="this.style.background='#eee';this.src=''">`;
        h += `
        <div class="card">
            ${avatarHtml}
            <div class="info">
                <div class="qq" data-qq="${htmlEscape(qq)}" onclick="copyQQ(this)" oncontextmenu="event.preventDefault();longPressQQ(this)">${htmlEscape(displayQQ)}</div>
            </div>
            <button class="blackDel" onclick="delBlack('${encodeURIComponent(qq)}')">移除</button>
        </div>
        `;
    });
    return h;
}
function renderLog(logArr){
    if(logArr.length===0) return '<div class="empty">暂无操作日志</div>';
    let h = '';
    logArr.forEach(line=>{
        const s = line.trim();
        if(s=="") return;
        h += `<div class="logItem">${htmlEscape(s)}</div>`;
    });
    return h;
}
function switchTab(index){
    currentTab = index;
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach((t,i)=>{
        if(i===index){
            t.classList.add('active');
        }else{
            t.classList.remove('active');
        }
    });
    document.getElementById('tabSlider').style.left = index*25 + '%';
    document.getElementById('contentContainer').style.transform = `translateX(-${index*25}%)`;
}
async function quickAddBlack(qq){
    await fetch(`?addBlack=${encodeURIComponent(qq)}`);
    showToast('已加入黑名单');
    refreshData();
}
let longPressTimer = null;
let longPressTriggered = false;
let isTouching = false;
function copyQQ(el){
    if(longPressTriggered) {
        longPressTriggered = false;
        return;
    }
    let qq = el.getAttribute('data-qq');
    if(!qq) return;
    if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(qq).then(()=>{
            showToast('已复制');
        }).catch(()=>{
            fallbackCopy(qq);
        });
    }else{
        fallbackCopy(qq);
    }
}
function fallbackCopy(text){
    let ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try{
        document.execCommand('copy');
        showToast('已复制');
    }catch(e){
        showToast('复制失败');
    }
    document.body.removeChild(ta);
}
function longPressQQ(el){
    clearTimeout(longPressTimer);
    longPressTriggered = false;
    let qq = el.getAttribute('data-qq');
    if(!qq) return;
    let currentRemark = remarksData[qq] || '';
    let newRemark = prompt('请输入备注（留空则清除备注）:', currentRemark);
    if(newRemark === null) return;
    newRemark = newRemark.trim();
    fetch(`?setRemark&qq=${encodeURIComponent(qq)}&remark=${encodeURIComponent(newRemark)}`)
        .then(()=>{
            showToast('备注已更新');
            refreshData();
        })
        .catch(()=>{
            showToast('更新备注失败');
        });
}
function setupLongPress(){
    document.addEventListener('touchstart', function(e) {
        let target = e.target.closest('.qq');
        if(!target) return;
        isTouching = true;
        longPressTimer = setTimeout(function(){
            longPressTriggered = true;
            longPressQQ(target);
        }, 500);
    }, {passive:true});
    document.addEventListener('touchend', function(e) {
        clearTimeout(longPressTimer);
        isTouching = false;
    }, {passive:true});
    document.addEventListener('touchmove', function(e) {
        clearTimeout(longPressTimer);
        isTouching = false;
    }, {passive:true});
    document.addEventListener('mousedown', function(e) {
        if(isTouching) return;
        let target = e.target.closest('.qq');
        if(!target) return;
        longPressTimer = setTimeout(function(){
            longPressTriggered = true;
            longPressQQ(target);
        }, 500);
    });
    document.addEventListener('mouseup', function(e) {
        clearTimeout(longPressTimer);
    });
    document.addEventListener('mouseleave', function(e) {
        clearTimeout(longPressTimer);
    });
}
setupLongPress();
async function refreshData(){
    const res = await fetch('?getData=1');
    const d = await res.json();
    remarksData = d.remarks || {};
    document.getElementById('waitBox').innerHTML = renderCardList(d.wait,true,remarksData);
    document.getElementById('doneBox').innerHTML = renderCardList(d.done,false,remarksData);
    document.getElementById('blackListWrap').innerHTML = renderBlack(d.black,remarksData);
    document.getElementById('logBox').innerHTML = renderLog(d.operLog);
}
async function handleDone(filename){
    await fetch(`?done=${filename}`);
    showToast('标记完成成功');
    refreshData();
}
async function handleDel(filename,isDone){
    let url = `?del=${filename}`;
    if(isDone) url += '&dir=done';
    await fetch(url);
    showToast('删除成功');
    refreshData();
}
async function addBlack(){
    const inp = document.getElementById('blackInput');
    const qq = inp.value.trim();
    if(!/^\d+$/.test(qq)){
        showToast('请输入纯数字QQ');
        return;
    }
    await fetch(`?addBlack=${encodeURIComponent(qq)}`);
    inp.value = '';
    showToast('添加黑名单成功');
    refreshData();
}
async function delBlack(qq){
    await fetch(`?delBlack=${encodeURIComponent(qq)}`);
    showToast('已移除黑名单');
    refreshData();
}
refreshData();
setInterval(refreshData,2000);
</script>
</body>
</html>