<?php
header('Content-Type: application/json; charset=utf-8');
function gip(){
    $sources=['HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','HTTP_X_REAL_IP'];
    foreach($sources as $s){
        if(!empty($_SERVER[$s])){
            $ips=explode(',',$_SERVER[$s]);
            foreach($ips as $i){
                $i=trim($i);
                if(filter_var($i,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4) && !preg_match('/^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|127\.)/',$i)){
                    return $i;
                }
            }
        }
    }
    $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';
    if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4) && !preg_match('/^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.|127\.)/',$ip)){
        return $ip;
    }
    return '0.0.0.0';
}
$ip=gip();
$f=__DIR__.'/data.json';if(!file_exists($f)){file_put_contents($f,json_encode(['records'=>[],'reminders'=>[],'blacklist'=>[],'auto_sign'=>[]],JSON_PRETTY_PRINT));}$d=json_decode(file_get_contents($f),1);if(!$d)$d=['records'=>[],'reminders'=>[],'blacklist'=>[],'auto_sign'=>[]];
if(isset($_GET['qq'])&&!isset($_GET['qd'])&&!isset($_GET['tx'])){$qq=trim($_GET['qq']);if(!preg_match('/^\d+$/',$qq)){echo json_encode(['状态码'=>2,'QQ号格式错误'=>true],JSON_UNESCAPED_UNICODE);exit;}$today=date('Y-m-d');$st='未签到';foreach($d['records'] as $r){if($r['qq']==$qq&&substr($r['time'],0,10)==$today){$st=($r['status']==='processed')?'已处理':'待处理';break;}}$rs=in_array($qq,$d['reminders'])?'开启':'关闭';$ad='未设置';foreach($d['auto_sign'] as $it){if($it['qq']==$qq){if($it['type']==='permanent')$ad='永久有效';elseif($it['type']==='longterm')$ad='长期有效';elseif(!empty($it['start'])&&!empty($it['end'])){$n=time();$e=strtotime($it['end']);if($e<$n)$ad='已过期';else{$x=ceil(($e-$n)/86400);$ad=($x==0)?'今天到期':'剩余'.$x.'天';}}break;}}$bk=false;foreach($d['blacklist'] as $it){if(($it['type']==='qq'&&$it['value']==$qq)||($it['type']==='ip'&&$it['value']==$ip)){$bk=true;break;}}echo json_encode(['状态码'=>0,'QQ号'=>$qq,'签到状态'=>$st,'提醒状态'=>$rs,'自动签到剩余时间'=>$ad,'是否黑名单'=>$bk?'是':'不是'],JSON_UNESCAPED_UNICODE);exit;}
if(isset($_GET['qq'])&&isset($_GET['qd'])){$qq=trim($_GET['qq']);if(!preg_match('/^\d+$/',$qq)){echo json_encode(['状态码'=>0,'参数不正确'=>true],JSON_UNESCAPED_UNICODE);exit;}$bk=false;foreach($d['blacklist'] as $it){if(($it['type']==='qq'&&$it['value']==$qq)||($it['type']==='ip'&&$it['value']==$ip)){$bk=true;break;}}if($bk){echo json_encode(['状态码'=>0,'你已被拉黑'=>true],JSON_UNESCAPED_UNICODE);exit;}$today=date('Y-m-d');$al=false;foreach($d['records'] as $r){if(substr($r['time'],0,10)==$today){if($r['qq']==$qq||$r['ip']==$ip){$al=true;break;}}}if($al){echo json_encode(['状态码'=>0,'请勿重复签到'=>true],JSON_UNESCAPED_UNICODE);exit;}$d['records'][]=['id'=>count($d['records'])+1,'qq'=>$qq,'time'=>date('Y-m-d H:i:s'),'status'=>'pending','ip'=>$ip,'remark'=>''];file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT));echo json_encode(['状态码'=>0,'签到成功'=>true],JSON_UNESCAPED_UNICODE);exit;}
if(isset($_GET['qq'])&&isset($_GET['tx'])){$qq=trim($_GET['qq']);if(!preg_match('/^\d+$/',$qq)){echo json_encode(['状态码'=>0,'参数不正确'=>true],JSON_UNESCAPED_UNICODE);exit;}$tx=intval($_GET['tx']);if($tx==1){if(!in_array($qq,$d['reminders'])){$d['reminders'][]=$qq;file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT));}echo json_encode(['状态码'=>0,'已开启提醒'=>true],JSON_UNESCAPED_UNICODE);}elseif($tx==0){$k=array_search($qq,$d['reminders']);if($k!==false){unset($d['reminders'][$k]);$d['reminders']=array_values($d['reminders']);file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT));}echo json_encode(['状态码'=>0,'已关闭提醒'=>true],JSON_UNESCAPED_UNICODE);}else{echo json_encode(['状态码'=>0,'无效操作'=>true],JSON_UNESCAPED_UNICODE);}exit;}
echo json_encode(['状态码'=>4,'缺少有效参数'=>true],JSON_UNESCAPED_UNICODE);