<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
require './PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$email = $_GET['email'] ?? '';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('{"code":400,"msg":"邮箱格式不正确"}');
}

$code = rand(100000, 999999);
$expire = time() + 300;

$data = [];
$file = 'codes.json';
if (file_exists($file)) {
    $data = json_decode(file_get_contents($file), true) ?? [];
}
$data[$email] = ['code' => $code, 'expire' => $expire];
file_put_contents($file, json_encode($data));

$mail = new PHPMailer(true);
try {
    $mail->CharSet = 'UTF-8';
    $mail->isSMTP();
    $mail->Host = 'smtp.163.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'YMKJ_YMX@163.com';
    $mail->Password = 'ZWPYZqtZNZifvfs4';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('YMKJ_YMX@163.com', '云喵科技');
    $mail->addAddress($email);
    $mail->isHTML(false);
    $mail->Subject = '云喵安全中心';
    $mail->Body = "您的验证码为：{$code}\n验证码5分钟内有效";

    $mail->send();
    echo '{"code":200,"msg":"验证码发送成功"}';
} catch (Exception $e) {
    echo '{"code":500,"msg":"验证码发送失败"}';
}
?>