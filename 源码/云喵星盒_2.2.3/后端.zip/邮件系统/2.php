<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$email = $_GET['email'] ?? '';
$code = $_GET['code'] ?? '';

if (!$email || !$code) {
    die('{"code":400,"msg":"参数不能为空"}');
}

$file = 'codes.json';
if (!file_exists($file)) {
    die('{"code":401,"msg":"验证码错误或已过期"}');
}
$data = json_decode(file_get_contents($file), true);
if (!isset($data[$email])) {
    die('{"code":401,"msg":"验证码错误或已过期"}');
}
$record = $data[$email];
if ($record['code'] != $code || time() > $record['expire']) {
    die('{"code":401,"msg":"验证码错误或已过期"}');
}

unset($data[$email]);
file_put_contents($file, json_encode($data));

echo '{"code":200,"msg":"验证成功"}';
?>